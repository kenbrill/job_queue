<?php
$mod_strings['LBL_JOBQUEUE_TITLE'] = 'Job Queue';
$mod_strings['LBL_JOBQUEUE_DESC'] = 'Front End Module for Job_Queue';


