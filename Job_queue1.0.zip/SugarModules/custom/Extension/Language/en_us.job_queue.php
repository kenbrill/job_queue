<?php

$app_list_strings['schedulers_status_dom']=array (
    'queued' => 'Queued',
    'running' => 'Running',
    'done' => 'Done',
    'hold' => 'On Hold',
);

$app_list_strings['schedulers_resolution_dom']=array (
    'queued' => 'Queued',
    'partial' => 'Partial',
    'success' => 'Success',
    'failure' => 'Failure',
    'running' => 'Running',
    'cancelled' => 'Cancelled',
);