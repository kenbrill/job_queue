# job_queue

This module gives the job_queue table a nice Sugar Front End.
With thei front end you can re-run jobs, cancel jobs and
kust generally monitor scheduled jobs.